import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { RestApiService } from '../shared/rest-api.service';

@Component({
  selector: 'app-employee-create',
  templateUrl: './employee-create.component.html',
  styleUrls: ['./employee-create.component.scss'],
})

export class EmployeeCreateComponent implements OnInit,OnDestroy {
  @Input() employeeDetails = { firstname: '',lastname:'',user_name:'',userPassword:'',email: '', is_project_manager:'',registrationtime:''  };
public ngUnsubscribe = new Subject();
  constructor(public restApi: RestApiService, public router: Router) {}
  ngOnDestroy(): void {

    this.ngUnsubscribe.complete();

  }

  ngOnInit() {}

  addEmployee(dataEmployee: any) {
    console.log(this.employeeDetails);
    this.restApi.createEmployee(this.employeeDetails).pipe(takeUntil(this.ngUnsubscribe)).subscribe((data: {}) => {
      this.router.navigate(['/employees-list']);
    });
  }
}
